<?php

/**
 * Path for the files
 */
$base_path = '/amxx/vip_manager';

/**
 * Database connection information
 * to read and store VIPs in the database
 * 
 * User should have SELECT, UPDATE, DELETE, and INSERT privileges
 */
$mysql_host = 'localhost';
$mysql_user = 'root';
$mysql_pass = '';
$mysql_db   = 'amxx';

/**
 * User accounts that can log into the administration pages
 * 
 * Format is as follows:
 * $admin_users->add_user('username', 'password');
 * 
 * For multiple users, you need multiple lines - one for each user
 */
$admin_users->add_user('admin', 'admin');