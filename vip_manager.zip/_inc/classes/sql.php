<?php
class SQL {
	private static $link = null;
	
	private $sql;
	private $result;
	private $affected_rows;
	private $insert_id;
	
	public function __construct($sql) {
		$link = $this->connect();
		$this->sql = $sql;
		$this->result = $link->query($sql);
		$this->affected_rows = $link->affected_rows;
		$this->insert_id = $link->insert_id;
	}
	
	public function affectedRows() {
		return $this->result ? $this->affected_rows : false;
	}
	
	private static function connect() {
		if(!self::$link) {
			global $mysql_host, $mysql_user, $mysql_pass, $mysql_db;
			self::$link = new mysqli($mysql_host, $mysql_user, $mysql_pass, $mysql_db);
		}
		return self::$link;
	}
	
	public static function escape($string) {
		return self::connect()->real_escape_string($string);
	}
	
	public function getInsertID() {
		return $this->insert_id;
	}
	
	public function getResult() {
		return $this->result;
	}
	
	public function getRow($field = null) {
		$value = false;
		if($this->result) {
			$value = $this->result->fetch_assoc();
			
			if($value && $field) {
				$value = isset($value[$field]) ? $value[$field] : false;
			}
		}
		return $value;
	}
	
	public function getRows($field = null) {
		$data = array();
		
		while($row = $this->getRow($field)) {
			$data[] = $row;
		}
		
		return $data;
	}
	
	public function getSQL() {
		return $this->sql;
	}
	
	public function numRows() {
		return $this->result ? $this->result->num_rows : false; 
	}
}