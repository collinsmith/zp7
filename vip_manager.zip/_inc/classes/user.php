<?php

class User {
	private $users = array();
	
	public function add_user($username, $password) {
		if($username && $password) {
			$this->users[$username] = $this->encrypt_password($username, $password);
			return true;
		}
		
		return false;
	}
	
	public function login($data) {
		if(!isset($data['username']) || !isset($data['password'])) {
			return false;
		}
		
		$username = $data['username'];
		$password = $this->encrypt_password($username, $data['password']);
		
		if(!isset($this->users[$username]) || $this->users[$username] != $password) {
			return false;
		}
		
		$_SESSION['username'] = $username;
		$_SESSION['password'] = $password;
		
		return true;
	}
	
	public function is_logged_in() {
		return (isset($_SESSION['username'])
			 && isset($_SESSION['password'])
			 && isset($this->users[$_SESSION['username']])
			 && $this->users[$_SESSION['username']] == $_SESSION['password']);
	}
	
	public function require_login() {
		if(!$this->is_logged_in()) {
			header('Location: index.php?returl=' . urlencode($_SERVER['REQUEST_URI']));
		}
	}
	
	public function logout() {
		unset($_SESSION['username']);
		unset($_SESSION['password']);
		
		session_destroy();
	}
	
	private function encrypt_password($username, $password) {
		return sha1($username . $password);
	}
}