<?php

class Base {
	private $table = null;
	private $primary_key = null;
	private $columns = array();
	
	public $info = array();
	
	/*
	 * Constructs a new Base class object
	 * 
	 * @param		table - The table which holds the information for this object
	 * 
	 * @return		A new Base class object
	 */
	public function __construct($table) {
		$this->table = $table;
		
		$sql = new SQL("DESCRIBE ".$this->table.";");
		
		$unique = null;
		
		while($row = $sql->getRow()) {
			if($row['Key'] == "PRI") {
				$this->primary_key = $row['Field'];
			}
			if($row['Key'] == "UNI") {
				$unique = $row['Field'];
			}
			$this->columns[] = $row['Field'];
		}
		
		if(!$this->primary_key) {
			$this->primary_key = $unique;
		}
	}
	
	/*
	 * PHP's magic method to get/set object properties
	 * It stores object db info into object->info and all properties that don't exist are looked for as columns in there
	 * 
	 * For example:
	 * $object->title accesses the "title" column from the database, located at $object->info['title']
	 */
	public function __get($name) {
		if(isset($this->$name)) {
			return $this->$name;
		} else if(array_key_exists($name, $this->info)) {
			return $this->info[$name];
		} else {
			return null;
		}
	}
	
	public function __set($name, $value) {
		if(isset($this->$name)) {
			$this->$name = $value;
		} else {
			$this->info[$name] = $value;
		}
	}
	
	/*
	 * Deletes given information from the database
	 * If no specific information is given, all rows are deleted
	 * 
	 * @param		whereArray - array structured to delete only what matches (eg. array('title' => 'Test Title Here') would delete only rows with that title)
	 * 
	 * @return		Number of rows deleted.
	 */
	public function delete($whereArray=null) {
		if(!$this->table || !$this->columns || !$this->primary_key) {
			return false;
		}
		
		$where = "";
		
		if($whereArray) {
			foreach($this->columns as $column) {
				if(isset($whereArray[$column])) {
					if($where) {
						$where .= " AND ";
					}
					$where .= $column."='".SQL::escape($whereArray[$column])."'";
				}
			}
		}
		
		$sql = new SQL("DELETE FROM ".$this->table.($where ? " WHERE " : "").$where.";");
		
		return $sql->affectedRows();
	}
	
	/*
	 * Gets all objects which match what you are looking for and orders how you want
	 * The where portion is similar to the search() and delete() functions
	 * If no whereArray is given, then all objects will be retrieved
	 * 
	 * @param		whereArray (optional, null) - Array of $column => $value pairs to look for
	 * @param		orderBy (optional, "") - The column to order by (and ASC/DESC), and can chain multiples separated by commas
	 * 
	 * @return		Array of found objects
	 */
	public function getAll($whereArray=null, $orderBy="") {
		if(!$this->table || !$this->columns || !$this->primary_key) {
			return false;
		}
		
		$where = "";
		
		foreach($this->columns as $column) {
			if(isset($whereArray[$column])) {
				if($where) {
					$where .= " AND ";
				}
				$where .= $column."='".SQL::escape($whereArray[$column])."'";
			}
		}
		
		if($where) {
			$where = " WHERE " . $where;
		}
		
		if($orderBy) {
			$orderBy = " ORDER BY " . $orderBy;
		}
		
		$sql = new SQL("SELECT ".$this->primary_key." FROM ".$this->table.$where.$orderBy.";");
		
		$objects = array();
		
		$class = get_called_class();
		$this_class = get_class();
		
		while($id = $sql->getRow($this->primary_key)) {
			if($class == $this_class) {
				$object = new $class($this->table);
				$object->load($id);
			} else {
				$object = new $class($id);
			}
			
			$objects[] = $object;
		}
		
		return $objects;
	}
	
	/*
	 * Loads the object based on given id
	 */
	public function load($id) {
		if(!$this->table || !$this->primary_key) {
			return false;
		}
		
		$sql = new SQL("SELECT * FROM ".$this->table." WHERE ".$this->primary_key." = '".SQL::escape($id)."';");
		
		$info = $sql->getRow();
		
		if($info) {
			$this->info = $info;
			return true;
		}
		
		return false;
	}
	
	/*
	 * Saves object with given information
	 * If no information is included, the object's own information will be used
	 * If no "id" is provided in the information, a new object is saved; otherwise, the object with that id is updated
	 * 
	 * @param		saveArray - Array of $column => $value pairs to save
	 * 
	 * @return		True on success, false on failure
	 */
	public function save($saveArray=null) {
		if(!$this->table || !$this->columns || !$saveArray && !$this->info) {
			return false;
		}
		
		if(!$saveArray) {
			$saveArray = $this->info;
		}
		
		$columns = $values = $update = "";
		$primary_key = $primary_value = false;
		
		foreach($this->columns as $field) {
			if(isset($saveArray[$field])) {
				$value = SQL::escape($saveArray[$field]);
				
				if($field == $this->primary_key) {
					$primary_key = $field;
					$primary_value = $value;
				} else {
					if($columns) {
						$columns .= ",";
					}
					$columns .= $field;
					
					if($values) {
						$values .= ",";
					}
					$values .= "'".$value."'";
					
					if($update) {
						$update .= ",";
					}
					$update .= $field."='".$value."'";
				}
			}
		}
		
		if(!$columns) {
			return false;
		}
		
		if($primary_key) {
			$sql = "UPDATE ".$this->table." SET ".$update." WHERE ".$primary_key."='".$primary_value."';";
		} else {
			$sql = "INSERT INTO ".$this->table." (".$columns.") VALUES (".$values.");";
		}
		
		$sql = new SQL($sql);
		
		if(!isset($this->info[$this->primary_key])) {
			return $this->load($sql->getInsertID());
		}
		
		return true;
	}
}