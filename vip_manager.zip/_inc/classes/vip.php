<?php

class Vip extends Base {
	private $type_strings = array(
		0 => 'Name',
		1 => 'SteamID',
		2 => 'IP',
		3 => 'Tag'
	);
	
	private $allowed_flags = "abcdefghijklmnopqrstuvwxyz";
	
	public function __construct($id = 0) {
		parent::__construct('vip_users');
		
		if($id) {
			$this->load($id);
		}
	}
	
	public function load($id) {
		if(parent::load($id)) {
			$this->type_string = $this->type_strings[$this->auth_type];
			$this->password = $this->password ? 'Yes' : '';
            
            return true;
		}
        
        return false;
	}
	
	public function save($data) {
		$data['flags'] = $this->restrict_flags($data['flags']);
		
		return parent::save($data);
	}
	
	private function restrict_flags($flags) {
		$flags = strtolower($flags);
		$output = '';
		
		$len = strlen($this->allowed_flags);
		for($i = 0; $i < $len; $i++) {
			$flag = substr($this->allowed_flags, $i, 1);
			
			if(stripos($flags, $flag) !== false) {
				$output .= $flag;
			}
		}
		
		return $output;
	}
}