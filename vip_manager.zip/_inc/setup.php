<?php

// enable error reporting in case something goes wrong
error_reporting(E_ALL);
ini_set('display_errors', 1);

// prepare the session for login system
if(session_id() == '') {
	session_start();
}

// include necessary classes
require_once('classes/user.php');
require_once('classes/sql.php');
require_once('classes/base.php');
require_once('classes/vip.php');

// create global user object to handle logins
$admin_users = new User();

// include configuration for the site
require_once('config.php');

// include functions for the site
require_once('functions.php');