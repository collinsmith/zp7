<?php

function render_doctype() {
	echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">' . "\n";
	echo '<html xmlns="http://www.w3.org/1999/xhtml">' . "\n";
}

function render_common_css() {
	echo "\t" . '<link rel="stylesheet" type="text/css" href="css/reset.css" />' . "\n";
	echo "\t" . '<link rel="stylesheet" type="text/css" href="css/common.css" />' . "\n";
	echo "\t" . '<!--[if lt IE 10]>' . "\n";
	echo "\t" . '<link rel="stylesheet" type="text/css" href="css/ie.css" />' . "\n";
	echo "\t" . '<![endif]-->' . "\n";
}

function render_common_js() {
	echo "\t" . '<script type="text/javascript" src="http://code.jquery.com/jquery-1.7.1.min.js"></script>' . "\n";
}

function render_header() {
	global $admin_users;
	
	echo "\t" . '<div id="header">' . "\n";
	echo "\t\t" . '<h1>VIPs Manager';
	
	if($admin_users->is_logged_in()) {
		echo ' | <a id="logout" href="index.php?logout">Logout</a>';
	}
	
	echo '</h1>' . "\n";
	
	echo "\t" . '<!--[if lt IE 8]>' . "\n";
	echo "\t" . '<p style="color:#fff;margin-top:10px;">You should really get a new browser.</p>' . "\n";
	echo "\t" . '<![endif]-->' . "\n";
	echo "\t" . '</div>' . "\n";
	echo "\t" . '<div id="content">' . "\n";
}

function render_footer() {
	echo "\t" . '<br style="clear:both;" />' . "\n";
	echo "\t" . '</div>' . "\n";
	echo "\t" . '<p id="footer">Management tool developed by Exolent</p>' . "\n";
}

function read_flags($string) {
    $flags = 0;
    
    $chars = array('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z');
    
    for($index = 0; $index < 26; $index++) {
        if(stripos($string, $chars[$index]) !== false) {
            $flags |= (1 << ($index));
        }
    }
    
    return $flags;
}

function get_flags($flags) {
    $string = '';
    
    $chars = array('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z');
    
    for($index = 0; $index < 26; $index++) {
        if($flags & (1 << $index)) {
            $string .= $chars[$index];
        }
    }
    
    return $string;
}

// Fix for those using older PHP versions that do not include get_called_class() function
if(!function_exists("get_called_class")) {
	function get_called_class() {
		foreach(debug_backtrace() as $trace) {
			if(isset($trace['object']) && $trace['object'] instanceof $trace['class']) {
				return get_class($trace['object']);
			}
		}
		return false;
	}
}