<?php

require_once('_inc/setup.php');

// default to no error message
$error_message = '';

// check if wanted to logout
if(isset($_GET['logout'])) {
	$admin_users->logout();
}

// check if just tried to login
if(isset($_POST['username']) && isset($_POST['password']) && !$admin_users->login($_POST)) {
	$error_message = 'Invalid username or password.';
}

// check if logged in
if($admin_users->is_logged_in()) {
	// if logged in, redirect
	if(isset($_REQUEST['returl']) && $_REQUEST['returl'] != '') {
		$url = urldecode($_REQUEST['returl']);
	} else {
		$url = 'home.php';
	}
	
	header('Location: ' . $url);
}

render_doctype();
?>
<head>
	<title>AMXX VIPs Manager - Login</title>
	
	<!-- CSS styles here -->
<?php render_common_css(); ?>
	<link rel="stylesheet" type="text/css" href="css/login.css" />
	
	<!-- JS scripts here -->
<?php render_common_js(); ?>
</head>
<body>
<?php render_header(); ?>
		<div id="login_container" class="module">
			<form action="index.php" method="post">
				<input type="hidden" name="returl" value="<?=isset($_REQUEST['returl']) ? urlencode($_REQUEST['returl']) : ''?>" />
				
				<label for="username">Username:</label><br />
				<input type="text" name="username" /><br /><br />
				
				<label for="password">Password:</label><br />
				<input type="password" name="password" /><br /><br />
				
				<input type="submit" value="Login" />
			</form>
		</div>
<?php render_footer(); ?>
</body>
</html>