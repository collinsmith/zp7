<?php

require_once('_inc/setup.php');

$admin_users->require_login();

$vip_users = new Vip();

if(isset($_POST['ajax'])) {
	$output = array();

	if(isset($_POST['action'])) {
		switch($_POST['action']) {
			case 'delete':
				if(isset($_POST['ids'])) {
					$ids = $_POST['ids'];
					
					if(is_array($ids) && $ids) {
						foreach($ids as $id) {
							$vip_users->delete(array('id' => $id));
						}
					} else {
						$output['error'] = "Invalid input for user ids.";
					}
				} else {
					$output['error'] = "No user ids provided.";
				}
				break;
            case 'load':
                if(isset($_POST['id'])) {
                    $vip_users->load($_POST['id']);
                    
                    if($vip_users->id) {
                        $output = $vip_users->info;
                        $output['expire'] = ($vip_users->date_remove == '0000-00-00') ? 0 : 1;
                    } else {
                        $output['error'] = "User not found.";
                    }
                } else {
                    $output['error'] = "No user id provided.";
                }
                break;
            case 'save':
                if(!isset($_POST['id']) || $vip_users->load($_POST['id']) && $vip_users->id) {
					if(!isset($_POST['use_password']) || !$_POST['use_password']) {
						$_POST['password'] = '';
					}
					
                    if($vip_users->save($_POST)) {
                        if(isset($_POST['id'])) {
                            $vip_users->load($vip_users->id);
                        }
                        
                        $vip_users->auth = htmlspecialchars($vip_users->auth);
                        
                        $output = $vip_users->info;
                        
                        $output['html']  = '<tr>';
                        $output['html'] .= '<td class="cell_icon"><input id="checkbox_user_' . $vip_users->id  . '" type="checkbox" class="checkbox_user" name="vip_users[]" value="' . $vip_users->id  . '" /></td>';
						$output['html'] .= '<td class="cell_auth_key">' . htmlspecialchars($vip_users->auth) . '</td>';
						$output['html'] .= '<td class="cell_auth_type">' . $vip_users->type_string . '</td>';
						$output['html'] .= '<td class="cell_flags">' . $vip_users->flags . '</td>';
						$output['html'] .= '<td class="cell_password">' . $vip_users->password . '</td>';
						$output['html'] .= '<td class="cell_expire_date">' . (($vip_users->date_remove == '0000-00-00') ? '-' : $vip_users->date_remove) . '</td>';
						$output['html'] .= '<td class="cell_icon"><a class="icon_button" href="javascript:editUser(' . $vip_users->id  . ');"><img src="images/icon_edit.png" alt="Edit" /></a></td>';
						$output['html'] .= '<td class="cell_icon"><a class="icon_button" href="javascript:deleteUser(' . $vip_users->id  . ');"><img src="images/icon_delete.png" alt="Delete" /></a></td>';
                        $output['html'] .= '</tr>';
                    } else {
                        $output['error'] = "Failed to save user info.";
                    }
                } else {
                    $output['error'] = "Invalid user id provided.";
                }
                break;
		}
	}
	
	echo json_encode($output);
	
	exit();
}

$vip_users = $vip_users->getAll();

render_doctype();
?>
<head>
	<title>AMXX VIPs Manager - Home</title>
	
	<!-- CSS styles here -->
<?php render_common_css(); ?>
	<link rel="stylesheet" type="text/css" href="css/home.css" />
    <link rel="stylesheet" type="text/css" href="jquery-ui/jquery-ui-1.8.17.custom.css" />
	
	<!-- JS scripts here -->
<?php render_common_js(); ?>
	<script type="text/javascript" src="js/home.js"></script>
    <script type="text/javascript" src="jquery-ui/jquery-ui-1.8.17.custom.min.js"></script>
</head>
<body>
<?php render_header(); ?>
		<div id="vip_list_container" class="module">
			<table cellspacing="0" cellpadding="0" border="0">
				<thead>
					<tr>
						<th class="cell_icon"><input type="checkbox" id="checkbox_all" /></th>
						<th class="cell_auth_key">Auth Key</th>
						<th class="cell_auth_type">Auth Type</th>
						<th class="cell_flags">Flags</th>
						<th class="cell_password">Password</th>
						<th class="cell_expire_date">Expire Date</th>
						<th class="cell_icon"></th>
						<th class="cell_icon"></th>
					</tr>
				</thead>
				<tbody>
<?php
if($vip_users) {
	$i = 0;
	foreach($vip_users as $vip_user) {
?>
					<tr<?php if(($i++ % 2) != 0) { ?> class="row_alt"<?php } ?>>
						<td class="cell_icon"><input id="checkbox_user_<?=$vip_user->id?>" type="checkbox" class="checkbox_user" name="vip_users[]" value="<?=$vip_user->id?>" /></td>
						<td class="cell_auth_key"><?=htmlspecialchars($vip_user->auth)?></td>
						<td class="cell_auth_type"><?=$vip_user->type_string?></td>
						<td class="cell_flags"><?=$vip_user->flags?></td>
						<td class="cell_password"><?=$vip_user->password?></td>
						<td class="cell_expire_date"><?=($vip_user->date_remove == '0000-00-00') ? '-' : $vip_user->date_remove?></td>
						<td class="cell_icon"><a class="icon_button" href="javascript:editUser(<?=$vip_user->id?>);"><img src="images/icon_edit.png" alt="Edit" /></a></td>
						<td class="cell_icon"><a class="icon_button" href="javascript:deleteUser(<?=$vip_user->id?>);"><img src="images/icon_delete.png" alt="Delete" /></a></td>
					</tr>
<?php
	}
} else {
?>
					<tr><td colspan="8">There are no VIP users.</td></tr>
<?php } ?>
				</tbody>
			</table>
			<p style="font-size:12px;" >With selected: <a href="javascript:deleteUsers();"><img src="images/icon_delete.png" alt="Delete" style="position:relative;top:2px;" /></a></p>
            
            <div id="user_forms">
                <div id="create_user" class="user_box">
                    <a id="create_user_toggle" href="javascript:createUserToggle();">
                        <img id="create_user_toggle_img" src="images/icon_downarrow.png" alt="V" />
                    </a>
                    
                    <h2>Create User</h2>
                    
                    <form action="home.php" method="post" style="display:none;">
                        <input type="hidden" name="ajax" value="1" />
                        <input type="hidden" name="action" value="save" />
                        
                        <label for="auth_type">Auth Type:</label><br />
                        <input type="radio" name="auth_type" value="0" /> Name<br />
                        <input type="radio" name="auth_type" value="1" checked="checked" class="default_radio" /> SteamID<br />
                        <input type="radio" name="auth_type" value="2" /> IP<br />
                        <input type="radio" name="auth_type" value="3" /> Tag<br /><br />
                        
                        <label for="auth">Auth:</label><br />
                        <input type="text" name="auth" /><br /><br />
                        
                        <label for="flags">Flags:</label><br />
                        <input type="text" name="flags" /><br /><br />
						
						<label for="password">Password: <input type="checkbox" name="use_password" value="1" /></label><br />
						<input type="password" name="password" disabled="disabled" style="opacity: 0.5;" /><br /><br />
                        
                        <label for="expire">Expire?</label><br />
                        <input type="radio" name="expire" value="1" /> Yes<br />
                        <input type="radio" name="expire" value="0" checked="checked" class="default_radio" /> No<br /><br />
                        
                        <p class="create_user_date" style="display:none;">
                            <label for="date_remove">Expiration Date:</label><br />
                            <input type="text" name="date_remove" class="date_picker" />
                        </p>
                        
                        <input type="button" onclick="createUser();return false;" value="Create User" />
                        <input type="button" onclick="cancelUser();return false;" value="Cancel" />
                    </form>
                </div>
                
                <div id="edit_user" class="user_box">
                    <h2>Edit User</h2>
                    
                    <form action="home.php" method="post" style="display:none;">
                        <input type="hidden" name="ajax" value="1" />
                        <input type="hidden" name="action" value="save" />
                        <input type="hidden" name="id" value="" />
                        
                        <label for="auth_type">Auth Type:</label><br />
                        <input type="radio" name="auth_type" value="0" /> Name<br />
                        <input type="radio" name="auth_type" value="1" checked="checked" class="default_radio" /> SteamID<br />
                        <input type="radio" name="auth_type" value="2" /> IP<br />
                        <input type="radio" name="auth_type" value="3" /> Tag<br /><br />
                        
                        <label for="auth">Auth:</label><br />
                        <input type="text" name="auth" /><br /><br />
                        
                        <label for="flags">Flags:</label><br />
                        <input type="text" name="flags" /><br /><br />
						
						<label for="password">Password: <input type="checkbox" name="use_password" value="1" /></label><br />
						<input type="password" name="password" disabled="disabled" style="opacity: 0.5;" /><br /><br />
                        
                        <label for="expire">Expire?</label><br />
                        <input type="radio" name="expire" value="1" /> Yes<br />
                        <input type="radio" name="expire" value="0" checked="checked" class="default_radio" /> No<br /><br />
                        
                        <p class="create_user_date" style="display:none;">
                            <label for="date_remove">Expiration Date:</label><br />
                            <input type="text" name="date_remove" class="date_picker" />
                        </p>
                        
                        <input type="button" onclick="editUserSubmit();return false;" value="Save Changes" />
                        <input type="button" onclick="cancelEditUser();return false;" value="Cancel" />
                    </form>
                </div>
            </div>
		</div>
<?php render_footer(); ?>
</body>
</html>