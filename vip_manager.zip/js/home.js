function init() {
	// add checkbox for all items functionality
	$("#checkbox_all").change(function() {
		if($(this).attr("checked")) {
			$("#vip_list_container .checkbox_user").attr("checked", "checked");
		} else {
			$("#vip_list_container .checkbox_user").removeAttr("checked");
		}
	});
	
	// keep checkbox for all items updated when an individual checkbox is changed
	$("#vip_list_container .checkbox_user").change(function() {
		if($("#vip_list_container .checkbox_user").length == $("#vip_list_container .checkbox_user:checked").length) {
			$("#checkbox_all").attr("checked", "checked");
		} else {
			$("#checkbox_all").removeAttr("checked");
		}
	});
	
	// toggle password for checkbox
	$("input[name=use_password]").change(function() {
		if($(this).attr("checked")) {
			$(this).parent().parent().find("input[name=password]").removeAttr("disabled").stop().animate({opacity: 1.0}, 'fast');
		} else {
			$(this).parent().parent().find("input[name=password]").attr("disabled", "disabled").stop().animate({opacity: 0.5}, 'fast');
		}
	});
	
	// slider for date picker in create user form
	$("input[name=expire]").change(function() {
		if($(this).val() == '1') {
			$(this).parent().children(".create_user_date").stop().slideDown('fast');
		} else {
			$(this).parent().children(".create_user_date").stop().slideUp('fast');
		}
	});
    
    // add date picker functionality
    $(".date_picker").datepicker({dateFormat: "yy-mm-dd"});
}

$(init);

function editUser(id) {
    $.post('home.php', {'ajax': '1', 'action': 'load', 'id': id}, function(data) {
        if(typeof data == 'string') {
            console.log(data);
        } else if(data.error) {
            alert(data.error);
        } else {
            $("#edit_user input[name=id]").val(id);
            $("#edit_user input[name=auth_type]:checked").removeAttr("checked");
			
            $("#edit_user input[name=auth_type]").each(function() {
                if($(this).val() == data.auth_type) {
                    $(this).attr("checked", "checked");
                }
            });
			
            $("#edit_user input[name=auth]").val(data.auth);
            $("#edit_user input[name=flags]").val(data.flags);
			
			if(data.password) {
				$("#edit_user input[name=use_password]").attr("checked", "checked");
				$("#edit_user input[name=password]").removeAttr("disabled").css("opacity", "1.0").val(data.password);
			} else {
				$("#edit_user input[name=use_password]").removeAttr("checked");
				$("#edit_user input[name=password]").attr("disabled", "disabled").css("opacity", "0.5").val(data.password);
			}
			
            $("#edit_user input[name=expire]:checked").removeAttr("checked");
			
            $("#edit_user input[name=expire]").each(function() {
                if($(this).val() == data.expire) {
                    $(this).attr("checked", "checked");
                }
            });
			
            $("#edit_user input[name=date_remove]").val(data.date_remove);
            
            if(data.expire) {
                $("#edit_user .create_user_date").show();
            } else {
                $("#edit_user .create_user_date").hide();
            }
            
            $("#edit_user form").stop().slideDown('fast');
        }
    }, 'json');
}

function editUserSubmit(id) {
    if(!validateForm("#edit_user")) {
        return false;
    }
    
    var formData = $("#edit_user form").serialize();
    
    $.post('home.php', formData, function(data) {
        if(typeof data == 'string') {
            console.log(data);
        } else if(data.error) {
            alert(data.error);
        } else {
            // update the user in the table
            var $row = $("#checkbox_user_" + data.id).parent().parent();
            
            $row.children('.cell_auth_key').html(data.auth);
            $row.children('.cell_auth_type').html(data.type_string);
            $row.children('.cell_flags').html(data.flags);
			$row.children('.cell_password').html(data.password);
            $row.children('.cell_expire_date').html(data.date_remove == '0000-00-00' ? '-' : data.date_remove);
            
            cancelEditUser();
        }
    }, 'json');
    
    return false;
}

function cancelEditUser() {
    $("#edit_user form").slideUp('fast');
}

function deleteUser(id) {
	doDelete([id]);
}

function deleteUsers() {
	var ids = [];
	
	$("#vip_list_container .checkbox_user:checked").each(function() {
		// checkbox_user_##
		// 0123456789 12345
		ids.push(parseInt($(this).attr("id").substr(14)));
	});
	
	if(ids.length == 0) {
		alert("You did not select any users!");
	} else {
		doDelete(ids);
	}
}

function doDelete(usersList) {
    if(confirm("Are you sure you want to delete?")) {
        $.post('home.php', {'ajax': 1, 'action': 'delete', 'ids': usersList}, function(data) {
            // if data is string, then response is being debugged
            if(typeof(data) == 'string') {
                console.log(data);
            } else if(data.error) {
                alert(data.error);
            } else {
                // remove deleted rows
                for(var i in usersList) {
                    $("#vip_list_container #checkbox_user_" + usersList[i]).parent().parent().remove();
                }
                
                checkTableRows();
            }
        }, 'json');
    }
}

function checkTableRows() {
    // check if any users exist
    if($("#vip_list_container .checkbox_user").length == 0) {
        // display message that there are no users
        $("#vip_list_container tbody").html('<tr><td colspan="8">There are no VIP users.</td></tr>');
    } else {
        // fix alternate rows
        var i = 0;
        $("#vip_list_container tbody tr").each(function() {
            if((++i % 2) == 0) {
                $(this).addClass("row_alt");
            } else {
                $(this).removeClass("row_alt");
            }
        });
    }
}

function createUserToggle() {
	$("#create_user form").stop().slideToggle('fast');
	
	var $img = $("#create_user_toggle_img");
	
	if($img.attr("src").indexOf("down") > 0) {
		$img.attr({"src": "images/icon_uparrow.png", "alt": "^"});
	} else {
		$img.attr({"src": "images/icon_downarrow.png", "alt": "V"});
	}
}

function createUser() {
    if(!validateForm("#create_user")) {
        return false;
    }
    
    var formData = $("#create_user form").serialize();
    
    $.post('home.php', formData, function(data) {
        if(typeof data == 'string') {
            console.log(data);
        } else if(data.error) {
            alert(data.error);
        } else {
            $("#vip_list_container table tbody").append(data.html);
            
            checkTableRows();
            
            cancelUser();
            createUserToggle();
            
            init();
        }
    }, 'json');
    
    return false;
}

function cancelUser() {
    $("#create_user input[type=radio]:checked").removeAttr("checked");
    $("#create_user input[type=radio].default_radio").attr("checked", "checked");
    $("#create_user input[name=auth]").val("");
    $("#create_user input[name=flags]").val("");
	$("#create_user input[name=use_password]").removeAttr("checked");
	$("#create_user input[name=password]").attr("disabled", "disabled").css("opacity", "0.5").val("");
    $("#create_user input[name=date_remove]").val("");
    $("#create_user .create_user_date").hide();
}

function validateForm(container) {
    if(!validateAuth(container)) {
        alert("Invalid auth provided!");
        return false;
    }
    
    if(!validateFlags(container)) {
        alert("Invalid flags provided!");
        return false;
    }
	
	if(!validatePassword(container)) {
		alert("Invalid password provided!");
		return false;
	}
    
    if(!validateDate(container)) {
        alert("Invalid date provided!");
        return false;
    }
    
    return true;
}

function validateAuth(container) {
    var auth_type = $(container + " input[name=auth_type]checked").val();
    var auth = $.trim($(container + " input[name=auth]").val());
    
    if(auth == '') {
        return false;
    }
    
    if(auth_type == 1) {
        if(!auth.match(/STEAM_0:(0|1):\d+/)) {
            return false;
        }
    } else if(auth_type == 2) {
        if(!auth.match(/(([0-9]|[1-9][0-9]|1[0-9][0-9]|2([0-4][0-9]|5[0-5]))\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2([0-4][0-9]|5[0-5]))/)) {
            return false;
        }
    }
    
    return true;
}

function validateFlags(container) {
    var flags = $(container + " input[name=flags]").val();
    
    return flags.match(/[a-zA-Z]/i);
}

function validatePassword(container) {
	if($(container + " input[name=use_password]:checked").length > 0) {
		if($(container + " input[name=password]").val().length == 0) {
			return false;
		}
	}
	
	return true;
}

function validateDate(container) {
    if($(container + " input[name=expire]:checked").val() == 1) {
        var date = $.trim($(container + " input[name=date_remove]").val());
        
        if(date != '0000-00-00' && !date.match(/\d{4}-\d{2}-\d{2}/)) {
            return false;
        }
    }
    
    return true;
}